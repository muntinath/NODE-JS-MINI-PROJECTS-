const express = require("express");
const bodyParser = require("body-parser");

const app = express();


app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));

let list_items=[];


app.get("/", function (req, res) {
  let day = new Date();
  let day_parameters={
    day:"numeric",
    weekday:"long",
    month:"long"
  }
  let today = day.toLocaleDateString("en-US",day_parameters);
  res.render("list", { today: today, list_items:list_items });
});

app.post("/",function(req,res){
  let list_item=req.body.new_input;

  list_items.push(list_item);
  res.redirect("/")
  });

app.listen(3000, function (req, res) {
  console.log("Server running on port 3000....");
});
