# Continuing TODO APP V1

# "work" route added : Now  items can be added into "work_list" on localhost/3000/work
::::::::::::::::::::::::::::::::::::::::::::
#Continuing TODO APP V2

#Modified css style 

# Checkbox and checkbox functionality added: when checkbox is checked item color changes and item get strikes out.