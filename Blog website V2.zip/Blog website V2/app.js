const express=require('express');
const bodyParser =require('body-parser');
const ejs=require('ejs');
const _=require("lodash");

const HomeContent="The web development industry is quickly evolving, and companies need to keep ahead with innovations to stay competitive in the online world. Web development trends might seem to change even faster than they are implemented by most of the enterprises. However, if you want to position yourself an innovation-driven brand and trendsetter, you must be aware of all the current web tendencies. "
const AboutContent= "This bog is about web development and web development related technology"
const Contact="Phone:0123456978, email: xyz@gmail.com"
const app=express();


app.set('view engine','ejs');


app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'));

let posts=[];



app.get("/",function(req,res){
    res.render('home',{HomeContent: HomeContent, posts: posts})
});

app.get("/compose",function(req,res){
    res.render('compose')
});
app.get("/post",function(req,res){
    res.render('post',{posts: posts})
});



app.get("/about",function(req,res){
    res.render('about',{AboutContent: AboutContent})
});

app.get("/contact",function(req,res){
    res.render('contact',{Contact: Contact})
});

app.post("/compose",function(req,res){
    
    const post={title:req.body.title, content:req.body.content};
    posts.push(post);
    res.redirect("/");
    
});


app.get("/posts/:searchTitle",function(req,res){
    const searchTitle= _.lowerCase(req.params. searchTitle);
    
    posts.forEach(function(post){
        const ourTitle=_.lowerCase(post.title);
        if(searchTitle===ourTitle){
        res.render("single_post",{title: post.title ,content:post.content})};
    });
  
})

app.listen(3000,function(req,res){
    console.log('Server running on port 3000...');
});