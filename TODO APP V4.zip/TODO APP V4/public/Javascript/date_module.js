exports.getToday=function(){
  let day = new Date();
  let day_parameters = {
    day: "numeric",
    weekday: "long",
    month: "long",
  };
  let today = day.toLocaleDateString("en-US", day_parameters);

  return today
}
