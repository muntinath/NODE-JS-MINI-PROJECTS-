const express = require("express");
const bodyParser = require("body-parser");
const today=require(__dirname + "/public/Javascript/date_module.js")

const app = express();

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

let list_items = [];
let work_items = [];

app.get("/", function (req, res) {
 let today=today.getToday();
  res.render("index", { today: today, list_items: list_items });
});

app.get("/work", function (req, res) {
  res.render("index", { today: "Work_list", list_items: work_items });
});

app.post("/", function (req, res) {
  let list_item = req.body.new_input;
  if (req.body.submit_btn === "Work_list") {
    work_items.push(list_item);
    res.redirect("/work");
  } else {
    list_items.push(list_item);
    res.redirect("/");
  }
});

app.listen(3000, function (req, res) {
  console.log("Server running on port 3000....");
});
