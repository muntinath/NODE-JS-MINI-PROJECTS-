# Continuing TODO APP V1

# "work" route added : Now  items can be added into "work_list" on localhost/3000/work
::::::::::::::::::::::::::::::::::::::::::::
#Continuing TODO APP V2

#Modified css style 

# Checkbox and checkbox functionality added: when checkbox is checked item color changes and item get strikes out.

:::::::::::::::::::::::::::::::::::::::::::::

# Continued TODO APP V3

# All the  html components are written in separate files for the ease of code maintainability and reusability.

# A custom date module is created to get the current date and used it by importing to app.js file
